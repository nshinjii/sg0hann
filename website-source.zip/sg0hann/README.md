# sg0hann website

Install Node.js, then run `npm install` and `npm run dev`. Build with `npm run build` and upload the contents of dist/ to static hosting. Includes the latest deployed cursor effect and light mode. Video and map data are snapshots; external images and playback need internet access.
