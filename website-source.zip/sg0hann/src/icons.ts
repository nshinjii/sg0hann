const paths: Record<string, string> = {
  YouTube:
    'M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8ZM9.6 15.6V8.4l6.3 3.6-6.3 3.6Z',
  X: 'M18.9 1.2h3.7l-8.1 9.2L24 22.8h-7.4l-5.8-7.6-6.7 7.6H.4L9 13 0 1.2h7.6l5.3 7 6-7Zm-1.3 19.4h2L6.5 3.3H4.3l13.3 17.3Z',
  Kick: 'M1 1h8v7h3V4h4V1h7v7h-4v4h-4v3h4v4h4v4h-8v-4h-3v-4H9v8H1V1Z',
  TikTok:
    'M16.7 0H13v16.5a3.1 3.1 0 1 1-2.6-3.1V9.7a6.8 6.8 0 1 0 6.3 6.8V7.8a9.4 9.4 0 0 0 5.5 1.8V5.9A5.8 5.8 0 0 1 16.7 0Z',
  Discord:
    'M20.3 4.4a20 20 0 0 0-4.9-1.5l-.6 1.2a18.6 18.6 0 0 0-5.6 0l-.6-1.2a20 20 0 0 0-4.9 1.5C.6 9 .1 13.5.3 17.9a20 20 0 0 0 6 3l1.2-2a12.5 12.5 0 0 1-1.9-.9l.5-.4a14 14 0 0 0 11.8 0l.5.4-1.9.9 1.2 2a20 20 0 0 0 6-3c.3-5.1-.8-9.5-3.4-13.5ZM8 15.2c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4 2.2 1.1 2.1 2.4c0 1.3-.9 2.4-2.1 2.4Zm8 0c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4 2.2 1.1 2.1 2.4c0 1.3-.9 2.4-2.1 2.4Z',
};
export function socialIcon(name: string) {
  if (name === 'Instagram')
    return '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>';
  return `<svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor"><path d="${paths[name] || paths.YouTube}"/></svg>`;
}
