import './styles.css';
import { initCursor } from './cursor';
initCursor();
import { archive, maps } from './data';
import { socialIcon } from './icons';

type Video = {
  id: string;
  title: string;
  category: string;
  views: string;
  duration: string;
  project: string;
  image: string;
  date?: string;
};
const popular: Video[] = [
  {
    id: 'fEHrcWYw2uw',
    title: 'How to play OG Fortnite in 2026! (Project EZFN Tutorial)',
    category: 'Tutorials',
    views: '51K',
    duration: '1:38',
    project: 'EZFN',
    image: 'https://img.youtube.com/vi/fEHrcWYw2uw/hqdefault.jpg',
  },
  {
    id: 'fDPWkWORUKQ',
    title: 'How to play OG Fortnite in 2026! (Project Stellar Tutorial)',
    category: 'Tutorials',
    views: '22K',
    duration: '6:37',
    project: 'Stellar',
    image: 'https://img.youtube.com/vi/fDPWkWORUKQ/hqdefault.jpg',
  },
  {
    id: '1CvbBDM8hLM',
    title: 'How to Play OG Fortnite on Android (2026 EZFN Tutorial)',
    category: 'Tutorials',
    views: '20K',
    duration: '1:49',
    project: 'Android / EZFN',
    image: 'https://img.youtube.com/vi/1CvbBDM8hLM/hqdefault.jpg',
  },
  {
    id: 'Yk3SykaJNcI',
    title:
      'How To Play OG Fortnite Chapter 5 in 2026! (Project Rewind Tutorial)',
    category: 'Tutorials',
    views: '14K',
    duration: '2:22',
    project: 'Rewind',
    image: 'https://img.youtube.com/vi/Yk3SykaJNcI/hqdefault.jpg',
  },
  {
    id: 'ENPKn5Yrixo',
    title: 'INSANE 28 KILLS SOLO WIN! Project Stellar Chapter 2 Season 2',
    category: 'Gameplay',
    views: '14K',
    duration: '11:15',
    project: 'Stellar',
    image: 'https://img.youtube.com/vi/ENPKn5Yrixo/hqdefault.jpg',
  },
  {
    id: '97hZ0q0r6vc',
    title: 'INSANE 20 KILL SOLO WIN! EZFN Chapter 2 Season 2',
    category: 'Gameplay',
    views: '14K',
    duration: '9:24',
    project: 'EZFN',
    image: 'https://img.youtube.com/vi/97hZ0q0r6vc/hqdefault.jpg',
  },
];
const videos: Video[] = archive;
let query = '';
let shown = 24;
let typingTimer: ReturnType<typeof setTimeout>;
const avatar =
  'https://yt3.googleusercontent.com/pKcTH0rbFFwJynh1ruvOTaaH9eQc08qoChWhIfLqurLIMwMZHJ5BXtRvVXKci3IUH0orEO4d_WU=s160-c-k-c0x00ffffff-no-rj';
const banner =
  'https://yt3.googleusercontent.com/9gefjgouzfxrjMXn432OYIGpxPQPiJm7PFSFZwo-9TZKihlJMTiLN5XxxflJPWruSIq3_vEVMg=w1138-fcrop64=1,00005a57ffffa5a8-k-c0xffffffff-no-nd-rj';
let filter = 'All';
let counterObserver: IntersectionObserver | undefined;
const counterFrames = new Set<number>();
const view = document.querySelector<HTMLElement>('#view')!;
const dialog = document.querySelector<HTMLDialogElement>('#details')!;
const themeButton = document.querySelector<HTMLButtonElement>('#theme')!;
const escapeHtml = (value: string) =>
  value.replace(
    /[&<>"']/g,
    character =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        character
      ]!
  );
function updateTheme() {
  themeButton.textContent = document.documentElement.classList.contains('light')
    ? 'Dark mode'
    : 'Light mode';
}
try {
  if (localStorage.getItem('dev-theme') === 'light')
    document.documentElement.classList.add('light');
} catch {}
updateTheme();
themeButton.addEventListener('click', () => {
  document.documentElement.classList.toggle('light');
  try {
    localStorage.setItem(
      'dev-theme',
      document.documentElement.classList.contains('light') ? 'light' : 'dark'
    );
  } catch {}
  updateTheme();
});
function cards(items: Video[]) {
  return (
    '<div class="video-grid">' +
    items
      .map(
        video => `
    <article class="video-card">
      <button class="thumbnail" data-video="${video.id}" aria-label="Watch ${escapeHtml(video.title)}">
        <img src="${video.image}" alt="${escapeHtml(video.title)} thumbnail" loading="lazy" />
        <span class="rank">${video.date ? new Date(video.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '#' + (popular.findIndex(v => v.id === video.id) + 1)}</span>
        <span class="play" aria-hidden="true">▶</span><span class="duration">${video.duration}</span>
      </button>
      <div class="video-body"><div class="video-meta"><span>${video.project}</span><span class="view-count"><svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>${video.views} views</span></div>
      <h3><button data-video="${video.id}">${escapeHtml(video.title)}</button></h3>
      <span class="small">${video.category} · SG0HANN</span></div>
    </article>`
      )
      .join('') +
    '</div>'
  );
}
const cta = `<section class="community-call"><div><span class="eyebrow">FOLLOW THE CHANNEL</span><h2>Keep up with SG0HANN.</h2><p>New projects, gameplay and the next upload. Follow along.</p></div><div class="actions"><a class="button" href="https://www.youtube.com/@sg0hann" target="_blank" rel="noopener">Visit YouTube</a><a class="button secondary" href="https://discord.gg/Qcx36DXrrW" target="_blank" rel="noopener">Join Discord</a></div></section>`;
function arenaBlock() {
  return `<section class="section home-maps"><div class="section-head"><div><span class="eyebrow">LOAD INTO THE ARENA</span><h2>sg0hann’s maps</h2></div><a class="text-link" href="#arena">View both maps &amp; stats ↗</a></div><div class="home-map-grid">${maps.map((m, i) => `<article class="home-map-card"><img src="${m.image}" class="map-image" alt="${escapeHtml(m.title)}" loading="lazy"/><div class="home-map-body"><span class="small">${m.type} · ${m.maxPlayers} max players</span><h3>${i === 0 ? 'SG0HANN’s 1v1.' : escapeHtml(m.title)}</h3><p>${i === 0 ? 'Fast build fights. Quick respawns. First elimination wins the round. Warm up or challenge a friend.' : escapeHtml(m.description.split('\n')[0])}</p><span class="small">FORTNITE ISLAND CODE</span><strong class="home-island-code">${m.code}</strong><div class="actions"><button class="button" data-copy="${m.code}">Copy island code</button><a class="button secondary" href="https://fortnite.gg/island/${m.code}" target="_blank" rel="noopener">View island</a></div><p class="copy-result" role="status" data-copy-result="${m.code}"></p></div></article>`).join('')}</div></section>`;
}
function render() {
  clearTimeout(typingTimer);
  counterObserver?.disconnect();
  counterFrames.forEach(cancelAnimationFrame);
  counterFrames.clear();
  const requested = location.hash.slice(1) || 'home';
  const route = ['home', 'projects', 'arena', 'about', 'contact'].includes(
    requested
  )
    ? requested
    : 'home';
  document.querySelectorAll('[data-nav]').forEach(el => {
    el.classList.toggle('active', el.getAttribute('data-nav') === route);
    if (el.getAttribute('data-nav') === route)
      el.setAttribute('aria-current', 'page');
    else el.removeAttribute('aria-current');
  });
  if (route === 'home') {
    view.innerHTML = `
      <div class="channel-heading"><div class="creator-identity"><img src="./resources/logo.jpg" data-logo alt="sg0hann logo" /><div><strong>sg0hann</strong><span class="creator-subtitle">Fortnite content creator</span><span class="creator-role"><img class="albanian-flag" src="./assets/albania.svg" alt="Albanian flag"/> <span id="typing-role" class="role-streamer" aria-label="Streamer, Content Creator">Streamer</span><span class="typing-cursor" aria-hidden="true">|</span></span></div></div><a class="text-link" href="https://www.youtube.com/@sg0hann" target="_blank" rel="noopener">youtube.com/@sg0hann</a></div>
      <section class="hero">
        <div><div class="eyebrow">TUTORIALS / GAMEPLAY / COMMUNITY</div><h1>OG Fortnite.<br><em>Guides &amp; gameplay.</em></h1>
        <p>A place for the seasons you remember. Explore project tutorials, full matches and the most watched videos from SG0HANN.</p>
        <div class="actions"><a class="button" href="#projects">Watch popular videos</a><a class="button secondary" href="https://kick.com/sg0hann" target="_blank" rel="noopener">Watch on Kick</a></div></div>
        <div class="hero-feature"><button class="thumbnail" data-video="${popular[0].id}" aria-label="Watch the most popular EZFN tutorial"><img src="${popular[0].image}" alt="Project EZFN tutorial thumbnail" /><span class="feature-label">FEATURED VIDEO · 51K VIEWS</span><span class="play" aria-hidden="true">▶</span></button><div class="feature-caption"><span>01 / MOST WATCHED</span><strong>OG Fortnite in 2026 / EZFN</strong></div></div>
      </section>
      <div class="stats"><div><strong>4.41K</strong><span>YouTube subscribers</span></div><div><strong>394</strong><span>Channel uploads</span></div><div><strong>658K+</strong><span>Channel views</span></div><div><strong>SG0HANN</strong><span>OG Fortnite creator</span></div></div>
      <p class="snapshot-note">Channel figures checked 30 September 2026.</p>
      <section class="section"><div class="section-head"><div><span class="eyebrow">SELECTED FROM THE CHANNEL</span><h2>Most popular videos.</h2></div><a class="text-link" href="#projects">Explore all six</a></div>${cards(popular.slice(0, 3))}</section>
      ${arenaBlock()}${cta}`;
  } else if (route === 'projects') {
    view.innerHTML = `<div class="pagehead"><span class="eyebrow">SG0HANN / VIDEO LIBRARY</span><h1>Videos.</h1><a class="text-link" href="https://www.youtube.com/@sg0hann/videos" target="_blank" rel="noopener">See every upload on YouTube</a></div>
    <div class="library-toolbar"><div class="filters" aria-label="Filter videos">${['All', 'Tutorials', 'Gameplay'].map(t => `<button data-filter="${t}" class="${filter === t ? 'selected' : ''}" aria-pressed="${filter === t}">${t}</button>`).join('')}</div><label class="search-label"><span class="small">Search videos</span><input id="video-search" type="search" placeholder="Search the channel…" value="${escapeHtml(query)}" /></label></div>
    <section class="section library" id="library-results"></section>
    <details class="archive-embed"><summary>Full channel archive on YouTube</summary><p>Browse the channel’s complete upload playlist directly on YouTube.</p><iframe loading="lazy" title="Full SG0HANN upload archive" src="https://www.youtube-nocookie.com/embed/videoseries?list=UUR9uxbyH0S_sAfOoZLkm0FA" allowfullscreen></iframe><a class="text-link" href="https://www.youtube.com/@sg0hann/videos" target="_blank" rel="noopener">See every upload on YouTube</a></details>
    <section class="section"><div class="section-head"><div><h2>Popular videos.</h2><p>The six most popular uploads from SG0HANN’s YouTube Videos tab, in channel popularity order.</p></div></div>${cards(popular)}</section>${cta}`;
    renderLibrary();
  } else if (route === 'arena') {
    view.innerHTML = `<div class="pagehead"><span class="eyebrow">SG0HANN / FORTNITE ISLAND</span><h1>sg0hann’s maps</h1><h2>Your next 1v1<br><em>starts here.</em></h2><p>Build, fight, respawn. Bring a friend and settle it in the arena.</p></div>${mapsBlock()}<section class="section"><span class="eyebrow">HOW TO JOIN</span><div class="join-steps"><div><span>01</span><h3>Open Fortnite</h3><p>Launch the game and open Discover or Search.</p></div><div><span>02</span><h3>Enter the island code</h3><p>Search for 1557-0656-0043.</p></div><div><span>03</span><h3>Get into the fight</h3><p>Select SG0HANN 1v1 and play with your friends.</p></div></div></section>${cta}`;
  } else if (route === 'about') {
    view.innerHTML = `<div class="pagehead"><span class="eyebrow">BEHIND THE CHANNEL</span><h1>Behind the<br><em>channel.</em></h1></div><section class="creator-banner about-banner"><img src="${banner}" alt="SG0HANN’s YouTube channel banner" /></section><section class="about-layout"><div class="profile"><img src="${avatar}" alt="SG0HANN’s channel profile picture" /><h2>SG0HANN</h2><span>@sg0hann</span><a class="button" href="https://www.youtube.com/@sg0hann" target="_blank" rel="noopener">Visit the channel</a></div><div><h2>The seasons we keep coming back to.</h2><p>SG0HANN makes content about OG Fortnite projects: tutorials for getting into different seasons, gameplay, solo wins, keyboard ASMR and streams.</p><p>From EZFN and Stellar to Rewind and EON, the channel explores projects that bring earlier Fortnite experiences back into view.</p><div class="focus-list"><div><span>01</span><strong>Project tutorials</strong><p>Find a season and follow the guide.</p></div><div><span>02</span><strong>Gameplay &amp; solo wins</strong><p>Full matches, late game and high-kill games.</p></div><div><span>03</span><strong>Streams &amp; community</strong><p>Catch the channel on YouTube and Kick.</p></div></div></div></section>${cta}`;
  } else {
    view.innerHTML = `<div class="pagehead"><span class="eyebrow">SG0HANN / COMMUNITY</span><h1>Connect with<br><em>SG0HANN.</em></h1><p>The links shared on SG0HANN’s YouTube channel. Watch, follow and join the conversation.</p></div><section class="social-grid">
      ${[
        [
          'YouTube',
          'Tutorials, gameplay and uploads',
          'https://www.youtube.com/@sg0hann',
          'YT',
        ],
        ['Kick', 'Streams and live sessions', 'https://kick.com/sg0hann', 'K'],
        [
          'Discord',
          'Join SG0HANN’s community',
          'https://discord.gg/Qcx36DXrrW',
          'D',
        ],
        [
          'TikTok',
          'Find @sg0hann on TikTok',
          'https://www.tiktok.com/@sg0hann',
          'TK',
        ],
        ['X', 'Posts and updates', 'https://x.com/sg0hann', 'X'],
        [
          'Instagram',
          'Follow @sg0hann',
          'https://www.instagram.com/sg0hann/',
          'IG',
        ],
      ]
        .map(
          ([name, desc, url]) =>
            `<a class="social-card" href="${url}" target="_blank" rel="noopener"><span class="social-icon">${socialIcon(name)}</span><h2>${name}</h2><p>${desc}</p><span class="text-link">Open ${name}</span></a>`
        )
        .join('')}</section>`;
  }
  const logo = view.querySelector<HTMLImageElement>('[data-logo]');
  if (logo) {
    logo.addEventListener(
      'error',
      () => {
        logo.src = avatar;
      },
      { once: true }
    );
  }
  if (route === 'home') typeRole();
  observeCounters();
}
function typeRole() {
  const el = document.querySelector<HTMLElement>('#typing-role');
  if (!el || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const words = ['Streamer', 'Content Creator'];
  let word = 0;
  let index = words[0].length;
  let removing = true;
  const tick = () => {
    if (!el.isConnected) return;
    index += removing ? -1 : 1;
    el.textContent = words[word].slice(0, index);
    let delay = removing ? 65 : 95;
    if (index === 0) {
      removing = false;
      word = (word + 1) % words.length;
      el.className = word === 0 ? 'role-streamer' : 'role-creator';
      delay = 280;
    }
    if (index === words[word].length && !removing) {
      removing = true;
      delay = 2200;
    }
    typingTimer = setTimeout(tick, delay);
  };
  typingTimer = setTimeout(tick, 2200);
}
function renderLibrary() {
  const items = videos.filter(
    v =>
      (filter === 'All' ||
        (filter === 'Tutorials'
          ? /how/i.test(v.title)
          : /keyboard|asmr|gameplay/i.test(v.title))) &&
      v.title.toLowerCase().includes(query.toLowerCase())
  );
  document.querySelector('#library-results')!.innerHTML =
    `<p class="small result-count" role="status">${items.length} videos · Newest first</p>${items.length ? cards(items.slice(0, shown)) : '<div class="empty-state"><h2>No videos found.</h2><p>Try another title or choose All.</p></div>'}${items.length > shown ? '<button class="button secondary load-more" data-more>Load more videos</button>' : ''}`;
}
function mapsBlock() {
  return `<section class="creator-stats"><div class="section-head"><div><span class="eyebrow">FORTNITE.GG / CREATOR PROFILE</span><div class="fortnite-identity"><img src="https://cdn-0001.qstv.on.epicgames.com/062SZzp68lMMoNdTxL1xOo/image.jpg" alt="twitchsg0hann’s Fortnite.gg creator logo"/><h2>twitchsg0hann</h2></div></div><a class="text-link" href="https://fortnite.gg/creator/twitchsg0hann" target="_blank" rel="noopener">View creator ↗</a></div><div class="stats"><div><strong>2</strong><span>Published maps</span></div><div><strong>7.1K</strong><span>Minutes played</span></div><div><strong>36</strong><span>Favorites</span></div><div><strong>12</strong><span>Followers</span></div></div><p class="snapshot-note">Fortnite.gg snapshot · 30 September 2026 · 0 players online. Rounded totals as reported by the source.</p></section><section class="map-grid">${maps.map(m => `<article class="map-card"><img class="map-image" src="${m.image}" alt="${escapeHtml(m.title)}" loading="lazy"/><div class="map-body"><div class="video-meta"><span>${m.type}</span><span>${m.maxPlayers} max players</span></div><h2>${escapeHtml(m.title)}</h2><a class="small" href="https://fortnite.gg/creator/twitchsg0hann" target="_blank" rel="noopener">By twitchsg0hann</a><p class="map-description">${escapeHtml(m.description).replace(/\n/g, '<br>')}</p><div class="map-metrics"><div><strong>${m.minutes}</strong><span>Minutes played</span></div><div><strong>${m.favorites}</strong><span>Favorites</span></div><div><strong>${m.peak}</strong><span>All-time peak</span></div><div><strong>${m.players}</strong><span>Players now</span></div></div><div class="map-chart"><div class="chart-heading"><h3>Players · Yearly</h3><span class="small">Monthly peak</span></div>${chart(m)}<p class="small">${m.code === '8286-0045-6204' ? 'Published March 2026. Fortnite.gg has no September row in this snapshot.' : 'October 2025 – September 2026.'}</p><details><summary>View chart data</summary><table><thead><tr><th>Month</th><th>Peak players</th></tr></thead><tbody>${m.months.map((month, i) => `<tr><td>${month}</td><td>${m.peaks[i]}</td></tr>`).join('')}</tbody></table></details></div><p class="small">Released ${m.released} · Updated ${m.updated}</p><div class="map-code"><code>${m.code}</code><button class="button secondary" data-copy="${m.code}">Copy code</button></div><p class="copy-result" role="status" data-copy-result="${m.code}"></p><a class="text-link" href="https://fortnite.gg/island/${m.code}" target="_blank" rel="noopener">View map &amp; live stats on Fortnite.gg ↗</a></div></article>`).join('')}</section>`;
}
function chart(m: (typeof maps)[number]) {
  const max = Math.max(...m.peaks);
  const width = 560;
  const slot = 500 / m.peaks.length;
  return `<svg viewBox="0 0 ${width} 210" role="img" aria-label="Monthly peak player counts for ${escapeHtml(m.title)}"><line x1="40" y1="155" x2="550" y2="155" class="chart-grid"/><line x1="40" y1="25" x2="550" y2="25" class="chart-grid"/><text x="25" y="159" class="chart-text">0</text><text x="10" y="29" class="chart-text">${max}</text>${m.peaks
    .map((peak, i) => {
      const h = (peak / max) * 130,
        x = 45 + i * slot;
      return `<g><title>${m.months[i]}: ${peak} peak players</title><rect class="chart-bar" x="${x}" y="${155 - h}" width="${slot * 0.65}" height="${h}" rx="3"/><text class="chart-text" x="${x + slot * 0.32}" y="${147 - h}" text-anchor="middle">${peak}</text><text class="chart-text" x="${x + slot * 0.32}" y="179" text-anchor="middle">${m.months[i].split(' ')[0]}</text></g>`;
    })
    .join('')}</svg>`;
}
function observeCounters() {
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const counters = view.querySelectorAll<HTMLElement>(
    '.stats strong, .map-metrics strong'
  );
  const animate = (element: HTMLElement) => {
    const finalText = element.dataset.finalCount!;
    const match = finalText.match(/^([\d,.]+)(K?)(\+?)$/i);
    if (!match || reducedMotion) return;
    const target = Number(match[1].replace(/,/g, '')) * (match[2] ? 1000 : 1);
    const decimals = match[1].includes('.') ? match[1].split('.')[1].length : 0;
    const start = performance.now();
    const tick = (now: number) => {
      if (!element.isConnected) return;
      const progress = Math.min((now - start) / 1400, 1);
      const value = target * (1 - Math.pow(1 - progress, 3));
      element.textContent =
        progress === 1
          ? finalText
          : (match[2]
              ? (value / 1000).toFixed(decimals) + match[2]
              : Math.floor(value).toLocaleString('en-GB')) + match[3];
      if (progress < 1) {
        const frame = requestAnimationFrame(tick);
        counterFrames.add(frame);
      }
    };
    const frame = requestAnimationFrame(tick);
    counterFrames.add(frame);
  };
  if (reducedMotion || !('IntersectionObserver' in window)) return;
  counterObserver = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          counterObserver!.unobserve(entry.target);
          animate(entry.target as HTMLElement);
        }
      });
    },
    { threshold: 0.35 }
  );
  counters.forEach(element => {
    if (!/^[\d,.]+K?\+?$/i.test(element.textContent || '')) return;
    element.dataset.finalCount = element.textContent || '';
    counterObserver!.observe(element);
  });
}
function openVideo(id: string) {
  const video = popular.find(v => v.id === id) || videos.find(v => v.id === id);
  if (!video) return;
  document.querySelector('#detail-content')!.innerHTML = `
    <span class="eyebrow">${video.category} / ${video.views} VIEWS</span><h2 id="video-title">${escapeHtml(video.title)}</h2>
    <div id="player"><img class="player-preview" src="${video.image}" alt="${escapeHtml(video.title)} thumbnail" /></div>
    <div class="actions"><button class="button" id="load-player" data-load="${video.id}">Load video player</button><a class="button secondary" href="https://www.youtube.com/watch?v=${video.id}" target="_blank" rel="noopener">Watch on YouTube</a></div>
    <p class="small">If the player is unavailable, use Watch on YouTube.</p>`;
  dialog.showModal();
}
view.addEventListener('click', async event => {
  const target = event.target as HTMLElement;
  const filterButton = target.closest<HTMLElement>('[data-filter]');
  if (filterButton) {
    filter = filterButton.dataset.filter!;
    shown = 24;
    render();
  }
  if (target.closest('[data-more]')) {
    shown += 24;
    renderLibrary();
  }
  const copier = target.closest<HTMLElement>('[data-copy]');
  if (copier) {
    const code = copier.dataset.copy!;
    const status = view.querySelector<HTMLElement>(
      `[data-copy-result="${code}"]`
    )!;
    try {
      await navigator.clipboard.writeText(code);
      status.textContent = `Island code copied: ${code}`;
    } catch {
      status.textContent = `Copy this code: ${code}`;
    }
  }
  const videoButton = target.closest<HTMLElement>('[data-video]');
  if (videoButton) openVideo(videoButton.dataset.video!);
  if (target.closest('#copy-code')) {
    const status = document.querySelector<HTMLElement>('#copy-result')!;
    try {
      await navigator.clipboard.writeText('1557-0656-0043');
      status.textContent = 'Island code copied: 1557-0656-0043';
    } catch {
      status.textContent = 'Copy this code: 1557-0656-0043';
    }
  }
});
dialog.addEventListener('click', event => {
  const target = event.target as HTMLElement;
  const loader = target.closest<HTMLElement>('[data-load]');
  if (loader) {
    document.querySelector('#player')!.innerHTML =
      `<iframe title="SG0HANN video player" src="https://www.youtube-nocookie.com/embed/${loader.dataset.load}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
    loader.remove();
  }
});
document
  .querySelector('#close-dialog')!
  .addEventListener('click', () => dialog.close());
dialog.addEventListener('close', () => {
  document.querySelector('#detail-content')!.innerHTML = '';
});
window.addEventListener('hashchange', () => {
  dialog.close();
  render();
  window.scrollTo(0, 0);
});
render();

view.addEventListener('input', event => {
  const input = event.target as HTMLInputElement;
  if (input.id === 'video-search') {
    query = input.value;
    shown = 24;
    renderLibrary();
  }
});
