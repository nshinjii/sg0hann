export function initCursor() {
  const enabled = window.matchMedia('(hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)');
  const cursor = document.createElement('div');
  cursor.className = 'custom-cross-cursor';
  cursor.setAttribute('aria-hidden', 'true');
  cursor.innerHTML = '<svg viewBox="0 0 24 24"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6Z"/></svg>';
  const canvas = document.createElement('canvas');
  canvas.className = 'custom-cursor-trail';
  canvas.setAttribute('aria-hidden', 'true');
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  document.body.append(canvas, cursor);
  let frame = 0;
  let x = 0;
  let y = 0;
  let smoothX = 0;
  let smoothY = 0;
  let lastMove = 0;
  const points: {x: number; y: number}[] = [];
  const resize = () => {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = window.innerWidth * ratio;
    canvas.height = window.innerHeight * ratio;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  };
  const stop = () => {
    cancelAnimationFrame(frame);
    frame = 0;
    points.length = 0;
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    document.documentElement.classList.remove('custom-cursor-active');
    cursor.classList.remove('is-visible');
  };
  const draw = (now: number) => {
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    smoothX += (x - smoothX) * 0.2;
    smoothY += (y - smoothY) * 0.2;
    if (now - lastMove < 100) points.push({x: smoothX, y: smoothY});
    else points.shift();
    if (points.length > 22) points.shift();
    if (points.length > 2) {
      const first = points[0];
      const gradient = ctx.createLinearGradient(first.x, first.y, x + 0.01, y + 0.01);
      gradient.addColorStop(0, 'rgba(168,85,247,0)');
      gradient.addColorStop(1, 'rgba(200,100,255,0.9)');
      ctx.beginPath();
      ctx.moveTo(first.x, first.y);
      points.slice(1).forEach(p => ctx.lineTo(p.x, p.y));
      ctx.lineTo(x, y);
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 2.5;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.shadowColor = 'rgba(168,85,247,0.55)';
      ctx.shadowBlur = 10;
      ctx.stroke();
    }
    frame = points.length || now - lastMove < 100 ? requestAnimationFrame(draw) : 0;
  };
  document.addEventListener('pointermove', event => {
    if (!enabled.matches || event.pointerType !== 'mouse') return;
    const target = event.target instanceof Element ? event.target : null;
    if (target?.closest('dialog, iframe')) { stop(); return; }
    x = event.clientX;
    y = event.clientY;
    if (!cursor.classList.contains('is-visible')) { smoothX = x; smoothY = y; }
    cursor.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    cursor.classList.add('is-visible');
    cursor.classList.toggle('is-hovering', !!target?.closest('a, button, summary, input, [role="button"]'));
    document.documentElement.classList.add('custom-cursor-active');
    lastMove = performance.now();
    if (!frame) frame = requestAnimationFrame(draw);
  }, {passive: true});
  document.documentElement.addEventListener('pointerleave', stop);
  window.addEventListener('blur', stop);
  window.addEventListener('resize', resize);
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); });
  enabled.addEventListener('change', stop);
  resize();
}
